package ProgettoPROG2.Agenzia;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import ProgettoPROG2.FramePricipali.Login;
import ProgettoPROG2.Parchi.Gestore;


public class FrameAgenzia extends JFrame{
	private ArrayList<Pacchetto> pacchetti;
	private Agenzia agenzia;
	private JButton bottone1;
	private JButton bottone2;
	private JButton bottone3;
	private JButton bottoneIndietro;
	private Gestore gestore;
    /**
     * costruttore Frame Agenzia
     * @param a Agenzia
     * @param g Gestore
     */
	public FrameAgenzia(Agenzia a,Gestore g)
	{
		this.gestore=g;
		this.agenzia=a;
		setTitle("Agenzia");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    
	    Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
	    setBounds(d.height/200,d.width/100,400,300);
	    JPanel panel=creaBottoni();
	    add(panel);
	    setVisible(true);
    }
	/**
	 * crea i bottoni principali nel frame
	 * @return JPanel che contiene i bottoni
	 */
	public JPanel creaBottoni(){
		bottone1=new JButton("Crea Pacchetto");
		
		class bottone1list implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				FrameCreaPacchetto f=new FrameCreaPacchetto(agenzia,gestore);
				dispose();
			}
			
		}
		ActionListener l1= new bottone1list();
		bottone1.addActionListener(l1);
		
		bottone2=new JButton("Vendi Pacchetto");
		class bottone2list implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				FrameVendiPacchetto v=new FrameVendiPacchetto(agenzia,gestore);
				dispose();
			}
			
		}
		ActionListener l2=new bottone2list();
		bottone2.addActionListener(l2);
		
		bottone3=new JButton("Visualizza Info");
		class bottone3list implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				FrameVisualizzaIncassoPacchetti i=new FrameVisualizzaIncassoPacchetti(agenzia,gestore);
				dispose();
			}
			
		}
		ActionListener l3=new bottone3list();
		bottone3.addActionListener(l3);
		
		bottoneIndietro=new JButton("Indietro");
		class IndietroListener implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				Login fg=new Login(gestore);
				dispose();
			}
			
		}
		ActionListener listener4=new IndietroListener();
		bottoneIndietro.addActionListener(listener4);
		
        JPanel bottoni=new JPanel();
        bottoni.add(bottone1);
        bottoni.add(bottone2);
        bottoni.add(bottone3);
        add(bottoneIndietro,BorderLayout.SOUTH);
        return bottoni;
	}
}




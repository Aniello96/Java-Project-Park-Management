package ProgettoPROG2.Agenzia;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

import ProgettoPROG2.Parchi.Gestore;

public class FrameVisualizzaIncassoPacchetti extends JFrame{
	private Agenzia agenzia;
	private JLabel AgenziaLabel;
	private JPanel topPanel;
	private DefaultListModel listModel;
	private ArrayList<Pacchetto> listaPacchetti;
	private JList listbox;
	private JScrollPane scroll;
	private JButton bottoneIndietro;
	private Gestore gestore;
	/**Costruttore di FrameVisualizzaIncassoPacchetti
	 * @param a Agenzia
	 * @paramg Gestore
	 * */
	
	public FrameVisualizzaIncassoPacchetti(Agenzia a,Gestore g) {
		this.gestore=g;
		this.agenzia=a;
        listModel = new DefaultListModel();
		setTitle("Visualizza incasso");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-550, f.height/2-200, 1100, 400);
		createLabel();
		createButton();
		createJList();
		createPanel();
		
		setVisible(true);
	}
	//Metodo che crea la Label che visualiza l'username del cliente
	public void createLabel()
	{
		AgenziaLabel=new JLabel("Elenco di tutti i pacchetti venduti dall'Agenzia: "+agenzia.getUser()+", L'incasso è:"+agenzia.getIncasso());
	}
		
		/**Metodo che crea le liste di tutti i biglietti acquistati*/
	public void createJList()
	{
		topPanel = new JPanel();
		topPanel.setLayout( new BorderLayout() );
		getContentPane().add( topPanel );
        listaPacchetti = agenzia.getListaPacchettiAcquistati();
		for(Pacchetto p : listaPacchetti)
		{
			listModel.addElement(p.toString());
		}
		listbox = new JList( listModel );
		topPanel.add( listbox, BorderLayout.CENTER );
		scroll = new JScrollPane(listbox);
		listbox.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		topPanel.add(scroll);
	}
	
	
	/**Metodo che crea il Button indietro, per ritornare al frame principale.*/
	public void createButton()
	{
		bottoneIndietro = new JButton("INDIETRO");
		
		class AddBottoneIndietroListener implements ActionListener
		{
			
			public void actionPerformed(ActionEvent event) 
			{
				FrameAgenzia f= new FrameAgenzia(agenzia,gestore);
				dispose();
			}
		}
		
		ActionListener listener = new AddBottoneIndietroListener();
		bottoneIndietro.addActionListener(listener);
		
	}
	
	/**Il metodo crea il Jpanel principale, nel quale vengono aggiunte le altre componenti.*/
	public void createPanel()
	{
		JPanel pannelloNord = new JPanel();
		
		pannelloNord.add(AgenziaLabel);
		
		JPanel pannelloSud = new JPanel();
		
		pannelloSud.add(bottoneIndietro);
		
		add(pannelloNord, BorderLayout.NORTH);
		add(topPanel,BorderLayout.CENTER);
		add(pannelloSud, BorderLayout.SOUTH);
		
		
	}

}

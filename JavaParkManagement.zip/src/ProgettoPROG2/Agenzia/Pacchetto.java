package ProgettoPROG2.Agenzia;
public class Pacchetto {
	private String descrizione;
	private String nome;
	private String codice;
    private static int prezzo;
	private boolean prenotato;
	private boolean acquistato;
/**La classe pacchetto ha un unico costruttore , al quale passiamo un codice univoco, una descrizione ed un nome. 
 *  
 *  */
	public Pacchetto(String codiceUnivoco,String descrizione, String nome){
		this.codice=codiceUnivoco;
		this.descrizione=descrizione;
		this.nome=nome;
		this.prenotato=false;
		this.acquistato=false;
	}
	
	/**Il metodo verifica se due pacchetti sono uguali tra di loro.Passiamo al metodo come parametro un pacchetto p, e verifichiamo
	 * se il codice del pacchetto p  � uguale a quello della classe.In caso affermativo il metodo restituisce true , altrimenti false. */
	public boolean equals(Pacchetto p){
		if(this.codice.equals(p.getCodice())){
			return true;
		}
		else return false;
	}
	
	
	/**Il metodo restituisce il Codice del pacchetto ed il nome.*/
	public String toString(){
		return "COD:"+codice+"\nNome:"+nome;
	}
	
	/**Il metodo restituisce il codice del pacchetto.*/
	public String getCodice(){
		return codice;
	}
	
	/**Il metodo restituisce il nome del pacchetto.*/
	public String getNome() {
		return nome;
	}
	
	/**Il metodo restituisce la descrizione del pacchetto.*/
	public String getDescrizione(){
		return descrizione;
	}
	
	/**Il metodo restituisce il valore della variabile boolean acquistato,quindi true se il pacchetto � stato acquistato , false altrimenti.*/
	public boolean acquistato(){
		return acquistato;
	}
	
	/**Il metodo setta a true il valore della variabile boolean acquistato.*/
	public void acquista(){
		this.acquistato=true;
	}
	
	/**Il metodo setta a true il valore della variabile boolean prenotato.*/
	public void prenota(){
		this.prenotato=true;
	}
	
	/**Il metodo restituisce il valore della variabile boolean prenotato,quindi true se il pacchetto � stato prenotato , false altrimenti.*/
	public boolean prenotato() {
		return prenotato;
	}
	/**
	 * @return il prezzo
	 */
	public static int getPrezzo() {
		return prezzo;
	}
	/**
	 * @param prezzo il prezzo da settare
	 */
	public static void setPrezzo(int prezzo) {
		Pacchetto.prezzo = prezzo;
	}
}

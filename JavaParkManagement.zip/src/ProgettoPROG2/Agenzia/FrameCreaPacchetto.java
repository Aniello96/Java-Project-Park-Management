package ProgettoPROG2.Agenzia;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ProgettoPROG2.Parchi.Gestore;

public class FrameCreaPacchetto extends JFrame {
	private Agenzia agenzia;
	private JTextField NomeField;
	private JTextField DescrizioneField;
	private JTextField PrezzoField;
	private JButton bottoneIndietro;
	private Gestore gestore;

	/**Costruttore di FrameCreaPacchetto
	 * @param a Agenzia
	 * @paramg Gestore
	 * */
	public FrameCreaPacchetto(Agenzia a,Gestore g) {
		this.agenzia=a;
		this.gestore=g;
		setTitle("Crea Pacchetto");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-300, f.height/2-86, 600, 271);
		add(createLabelField(),BorderLayout.NORTH);
		add(createButton(),BorderLayout.SOUTH);
		setVisible(true);
	}
	
	/**Il metodo crea restituisce una Jpanel che viene posizionata nella parte superiore del Frame.*/
	public JPanel createLabelField(){
		JLabel NomePacchettoLabel = new JLabel("Nome Pacchetto: ");
		JLabel DescrizionePacchettoLabel=new JLabel("Descrizione Pacchetto: ");
		JLabel Prezzo=new JLabel("Prezzo: ");
		NomeField=new JTextField();
		DescrizioneField=new JTextField();
		PrezzoField=new JTextField();
		JPanel panel=new JPanel();
		panel.setLayout(new GridLayout(3, 2));
		panel.add(NomePacchettoLabel);
		panel.add(NomeField);
		panel.add(DescrizionePacchettoLabel);
		panel.add(DescrizioneField);
		panel.add(Prezzo);
		panel.add(PrezzoField);
		return panel;
	}
	
	/**Il metodo restituisce una Jpanel, ed al suo interno viene creato un bottone, il quale ha associato un listner che serve a creare
	 * un nuovo pacchetto. */
	public JPanel createButton(){
		JButton crea=new JButton("Crea Pacchetto");
		class creaPacchetto implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
				String nome=NomeField.getText();
				String descrizione=DescrizioneField.getText();
				try{
				int prezzo=Integer.parseInt(PrezzoField.getText());
				if(prezzo<=0||prezzo>10000){
					throw new IllegalArgumentException("Prezzo del pacchetto errato!!");
				}
				String codice=agenzia.creaPacchetto(nome,descrizione,prezzo);
				JOptionPane.showMessageDialog(null, "Pacchetto creato correttamente:\n"+agenzia.getPacchetto(codice).toString());
				}catch(IllegalArgumentException a){
					JOptionPane.showMessageDialog(null,"Inserire un prezzo adatto");
				}
				
			}
			
		}
		ActionListener listener=new creaPacchetto();
		crea.addActionListener(listener);
		
		bottoneIndietro=new JButton("Indietro");
		class IndietroListener implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				FrameAgenzia fg=new FrameAgenzia(agenzia,gestore);
				dispose();
			}
			
		}
		ActionListener listener3=new IndietroListener();
		bottoneIndietro.addActionListener(listener3);
		JPanel butt=new JPanel();
		butt.add(crea);
		butt.add(bottoneIndietro);
		return butt;
	}
	
}

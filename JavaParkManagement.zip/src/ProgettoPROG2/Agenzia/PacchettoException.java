package ProgettoPROG2.Agenzia;

public class PacchettoException extends RuntimeException{
public PacchettoException(){
	super("Il Cliente ha già acquistato un Pacchetto");
}
public PacchettoException(String message) {
	super(message);
	
}
}

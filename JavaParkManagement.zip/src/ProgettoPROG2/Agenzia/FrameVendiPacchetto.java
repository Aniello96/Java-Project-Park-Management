package ProgettoPROG2.Agenzia;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ProgettoPROG2.Parchi.*;
import ProgettoPROG2.Parchi.*;

public class FrameVendiPacchetto extends JFrame{
	private Agenzia agenzia;
	private JLabel NomeClienteLabel;
	private JLabel CognomeClienteLabel;
	private JLabel EtàLabel;
	private JLabel CodiceFiscaleLabel;
	private JLabel PacchettoSceltoLabel;
	private JTextField NomeField;
	private JTextField CognomeField;
	private JTextField EtàField;
	private JTextField CodiceFiscale;
	private JComboBox PacchettiBox;
	private ArrayList<Pacchetto> Pacchetti;
	private JButton bottoneVendi;
	private JButton bottoneIndietro;
	private ActionListener listener;
	private JPanel pannelloSceltaParco;
	private Gestore gestore;
	private JButton bottonePrenota;
    private Logger global;
    
    /**Costruttore di FrameVendiPacchetto
	 * @param a Agenzia
	 * @paramg Gestore
	 * */
    
	public FrameVendiPacchetto(Agenzia a,Gestore g) {
		try{
		this.gestore=g;
		this.agenzia=a;
		setTitle("Vendi Pacchetto");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-300, f.height/2-86, 600, 271);
		creaBottone();
		createComboBox();
		createLabel();
		createField();
		CreatePanel();
		setVisible(true);
		}catch(RuntimeException e){
			dispose();
			FrameCreaPacchetto f=new FrameCreaPacchetto(agenzia,gestore);
		}
		global=Logger.getLogger("logger");
	}
	
	
	/**Il metodo serve a creare le varie Label che il frame utilizzer�.*/
	public void createLabel(){
		NomeClienteLabel=new JLabel("Nome: ");
		CognomeClienteLabel=new JLabel("Cognome: ");
		EtàLabel=new JLabel("Età: ");
		CodiceFiscaleLabel=new JLabel("Codice Fiscale: ");
		PacchettoSceltoLabel=new JLabel("Scegli Pacchetto:");
		
	}
	
	/**Il metodo serve a creare le JtextField , dalle quali si preleveranno le informazioni
	 * riguardanti il nome,cognome , et� e CF della persona che vuole comprare un pacchetto.*/
	public void createField(){
		NomeField=new JTextField();
		CognomeField=new JTextField();
		EtàField=new JTextField();
		CodiceFiscale=new JTextField();
	}
	
	/**Il metodo crea un combobox, passando come paramentro  alla combobox l' arrayList dei pacchetti disponibili.*/
	public void createComboBox(){
		PacchettiBox=new JComboBox();
        Pacchetti=agenzia.getListapacchetti();
        if(Pacchetti.size()==0){
        	JOptionPane.showMessageDialog(null, "Lista pacchetti vuota: Procedere creando un nuovo pacchetto");
        	throw new RuntimeException();
        }
        else{
		for(Pacchetto p:Pacchetti){
			PacchettiBox.addItem(p.getCodice());
		}
		PacchettiBox.setEditable(true);
		PacchettiBox.addActionListener(listener);
        }
	}
	
	/**Il metodo serve a creare  il Jpanel principale, nel quale vengono aggiunte le JtextFiel e le JLabel.*/
	public void CreatePanel(){
		JPanel pannelloLabel=new JPanel();
		pannelloLabel.setLayout(new GridLayout(4, 1));
		pannelloLabel.add(NomeClienteLabel);
		pannelloLabel.add(NomeField);
		pannelloLabel.add(CognomeClienteLabel);
		pannelloLabel.add(CognomeField);
		pannelloLabel.add(EtàLabel);
		pannelloLabel.add(EtàField);
		pannelloLabel.add(CodiceFiscaleLabel);
		pannelloLabel.add(CodiceFiscale);
		
		pannelloSceltaParco=new JPanel();
		pannelloSceltaParco.add(PacchettoSceltoLabel);
		pannelloSceltaParco.add(PacchettiBox);
		JPanel bottoni=new JPanel();
		bottoni.add(bottonePrenota);
		bottoni.add(bottoneVendi);
		bottoni.add(bottoneIndietro);
		JPanel panel=new JPanel();
		panel.setLayout(new GridLayout(3, 1));

		panel.add(pannelloLabel);
		panel.add(pannelloSceltaParco);
		panel.add(bottoni);
		add(panel);
	}
	
	/**Il metodo crea due bottoni, vendi pacchetto e compra pacchetto, che hanno associati due listner in grado di far vendere o prenotare
	 * un determinato pacchetto.*/
	public void creaBottone(){
		bottoneVendi=new JButton("Vendi Pacchetto");
		class VendiListener implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				try{
					String nome=NomeField.getText();
					String cognome=CognomeField.getText();
					String CF=CodiceFiscale.getText();
					String dataNascita=EtàField.getText();
					int età=Integer.parseInt(dataNascita);
					Cliente C=new Cliente(nome, cognome, CF,età);
					if(nome.isEmpty()||cognome.isEmpty()||CF.isEmpty()||dataNascita.isEmpty()){
						JOptionPane.showMessageDialog(null,"Campi vuoti!");
					}
					else if((nome.length()>15||nome.length()<=1)||(cognome.length()>15||cognome.length()<=1)||CF.length()!=16){
						JOptionPane.showMessageDialog(null, "Campi non validi: inserisci Nome, Cognome e Codice Fiscale validi");
					}
				    else if(gestore.trovaCliente(C)){
				    	try{
				    	
							int index=PacchettiBox.getSelectedIndex();
							Pacchetto temp=Pacchetti.get(index);
						    agenzia.vendiPacchetto(temp, gestore.getCliente(CF));
					        JOptionPane.showMessageDialog(null, "Il Cliente: "+gestore.getCliente(CF).toString()+"\nHa Acquistato correttamente il Pacchetto: "+temp.toString());
					        dispose();
					        FrameAgenzia a=new FrameAgenzia(agenzia,gestore);
						}catch(PacchettoException p){
							JOptionPane.showMessageDialog(null, p.getMessage());
						}
				    } 
				    else{
				    	try{
							gestore.addCliente(C);
							int index=PacchettiBox.getSelectedIndex();
							Pacchetto temp=Pacchetti.get(index);
							agenzia.vendiPacchetto(temp, C);
						    JOptionPane.showMessageDialog(null, "Il Cliente: "+C.toString()+"\nHa Acquistato correttamente il Pacchetto: "+temp.toString());
						    dispose();
						    FrameAgenzia a=new FrameAgenzia(agenzia,gestore);
				    	}catch(PacchettoException p){
				    		JOptionPane.showMessageDialog(null, p.getMessage());
				    	}
					
				    }
				}
				catch(NumberFormatException n){
					JOptionPane.showMessageDialog(null, n.getMessage());
				}
			}
			
		}
		ActionListener listener2=new VendiListener();
		bottoneVendi.addActionListener(listener2);
		
		bottonePrenota=new JButton("Prenota Pacchetto");
		class PrenotaListener implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				try{
					String nome=NomeField.getText();
					String cognome=CognomeField.getText();
					String CF=CodiceFiscale.getText();
					String dataNascita=EtàField.getText();
					int età=Integer.parseInt(dataNascita);
					Cliente C=new Cliente(nome, cognome, CF,età);
					if(nome.isEmpty()||cognome.isEmpty()||CF.isEmpty()||dataNascita.isEmpty()){
						JOptionPane.showMessageDialog(null,"Campi vuoti!");
					}
					else if((nome.length()>15||nome.length()<=1)||(cognome.length()>15||cognome.length()<=1)||CF.length()!=16){
						JOptionPane.showMessageDialog(null, "Campi non validi: inserisci Nome, Cognome e Codice Fiscale validi");
					}
				    else if(gestore.trovaCliente(C)){
				    	try{
							int index=PacchettiBox.getSelectedIndex();
							Pacchetto temp=Pacchetti.get(index);
						    agenzia.prenotaPacchetto(temp, gestore.getCliente(CF));
					        JOptionPane.showMessageDialog(null, "Il Cliente: "+gestore.getCliente(CF).toString()+"\nHa prenotato correttamente il Pacchetto: "+temp.toString());
					        dispose();
					        FrameAgenzia a=new FrameAgenzia(agenzia,gestore);
						}catch(PacchettoException p){
							JOptionPane.showMessageDialog(null, p.getMessage());
						}
				    } 
				    else{
				    	try{
							gestore.addCliente(C);
							int index=PacchettiBox.getSelectedIndex();
							Pacchetto temp=Pacchetti.get(index);
							agenzia.prenotaPacchetto(temp, C);
						    JOptionPane.showMessageDialog(null, "Il Cliente: "+C.toString()+"\nHa prenotato correttamente il Pacchetto: "+temp.toString());
						    dispose();
						    FrameAgenzia a=new FrameAgenzia(agenzia,gestore);
				    	}catch(PacchettoException p){
				    		JOptionPane.showMessageDialog(null, p.getMessage());
				    	}
					    
				    }
				}
				catch(NumberFormatException n){
					JOptionPane.showMessageDialog(null, n.getMessage());
				}
			}
			
		}
		ActionListener listener3=new PrenotaListener();
		bottonePrenota.addActionListener(listener3);
		
		bottoneIndietro=new JButton("Indietro");
		class IndietroListener implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				FrameAgenzia fg=new FrameAgenzia(agenzia,gestore);
				dispose();
			}
			
		}
		ActionListener listener4=new IndietroListener();
		bottoneIndietro.addActionListener(listener4);
		}
		
}

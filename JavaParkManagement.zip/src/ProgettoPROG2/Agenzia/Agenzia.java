package ProgettoPROG2.Agenzia;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import ProgettoPROG2.Parchi.*;


public class Agenzia{
	
	/**
	 * Costruttore Agenzia
	 * @param login Nome Utente Agenzia
	 * @param Password Password dell'Agenzia
	 * @param g Gestore associato all'Agenzia
	 */
	public Agenzia(String login,String Password,Gestore g)
	{
		this.incasso=0;
		this.gestore=g;
		this.login=login;
	    this.Password=Password;
	    pacchettiAcquistati=new ArrayList<Pacchetto>();
	    pacchettidisponibili=new ArrayList<Pacchetto>();
	    listaClienti=gestore.getListaClienti();
    }
	
	/**Metodo che restituisce il  login.*/
	public String getUser(){
		return login;
	}
	
	/**Metodo che restituisce la password.*/
	public String getPassword(){
		return Password;
	}
	
	/**Metodo che restituisce la lista dei pacchetti disponibili.*/
	public ArrayList<Pacchetto> getListapacchetti(){
		return pacchettidisponibili;
	}
	
	/**Metodo che restituisce la lista dei pacchetti acquistati.*/
	public ArrayList<Pacchetto> getListaPacchettiAcquistati() {
		return pacchettiAcquistati;
	}
	/**
	 * metodo che crea un nuovo pacchetto e lo aggiunge alla lista dei pacchetti disponibili
	 * @param nome
	 * @param descrizione
	 * @param prezzo
	 */
	public String creaPacchetto(String nome,String descrizione,int prezzo) {
		String codiceUnivoco="PA".concat(nome.substring(0,2)).concat(Integer.toString(pacchettidisponibili.size()));
		Pacchetto p=new Pacchetto(codiceUnivoco, descrizione, nome);
		p.setPrezzo(prezzo);
		pacchettidisponibili.add(p);
		return codiceUnivoco;
	}
	/**
	 * metodo che cerca il nome del pacchetto tra quelli disponibili e ne ritorna un istanza nel caso lo trova
	 * @param nome
	 * @return
	 */
	public Pacchetto getPacchetto(String codice){
		Pacchetto p=null;
		for(Pacchetto pa:pacchettidisponibili){
			if(pa.getCodice().equals(codice)){
			   p=pa;
			}
		}
		return p;
	    
	}
	/**
	 * Controlla che Il cliente non abbia già acquistato altri Pacchetti, in tal caso lancia un'eccezione
	 * Controlla che il Pacchetto non sia già stato prenotato.
	 * Caso negativo: procede con l'acquisto.
	 * Caso positivo: se il cliente che desidera acquistare il pacchetto(passato come parametro) è lo stesso che lo abbia prenotato, lo acquista.
	 * altrimenti lancia un eccezione.
	 * @param p Pacchetto da Acquistare
	 * @param c Cliente che Acquista il pacchetto
	 */
	public void vendiPacchetto(Pacchetto p,Cliente c) {
		if(c.controllaAcquisto()==true){
			throw new PacchettoException();
		}
		else if(p.prenotato()){
			 if(c.controllaPrenotazione()){
					if(p.getCodice().equals(c.getPacchettoPrenotato().getCodice())){
							p.acquista();
							c.Acquista(p);
							pacchettiAcquistati.add(p);
							pacchettidisponibili.remove(p);
							incasso+=p.getPrezzo();
					}
					else
						throw new PacchettoException("Il Pacchetto è già stato prenotato da un'altro Cliente");
			   }
			 else
				throw new PacchettoException("Il Pacchetto è già stato prenotato da un'altro Cliente");
		}
		else{
					p.acquista();
					c.Acquista(p);
					pacchettiAcquistati.add(p);
					pacchettidisponibili.remove(p);
					incasso+=p.getPrezzo();
		}
	}
	/**
	 * metodo che permette a un cliente di prenotare un pacchetto
	 * @param p pacchetto prenotato
	 * @param c cliente che effettua la prenotazione
	 */
	public void prenotaPacchetto(Pacchetto p,Cliente c) {
		if(c.controllaAcquisto()){
			throw new PacchettoException();
		}
		else if(p.prenotato()){
			 if(c.controllaPrenotazione()){
				if(p.getCodice().equals(c.getPacchettoPrenotato().getCodice())){
					throw new PacchettoException("Il cliente: "+c.toString()+"\nHa già prenotato questo pacchetto, procedere all'Acquisto");
				}
				else
					throw new PacchettoException("Il Pacchetto è già stato prenotato da un'altro Cliente");
		     }
			
		}
		else{
			p.prenota();
			c.PrenotaPacchetto(p);
			pacchettidisponibili.remove(p);
			pacchettidisponibili.add(p);
		}
		
	}
    /**
     * metodo che ritorna l'incasso dell'agenzia
     * @return l'incasso
     */
	public int getIncasso(){
		return incasso;
	}
	private String login;
	private String Password;
	private Gestore gestore;
	private ArrayList<Pacchetto> pacchettidisponibili;
	private int incasso;
	private ArrayList<Pacchetto> pacchettiAcquistati;
	private ArrayList<Cliente> listaClienti;
}

package ProgettoPROG2.FramePricipali;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import ProgettoPROG2.Agenzia.*;
import ProgettoPROG2.Parchi.*;

public class Login extends JFrame{
	private Gestore gestore;
	private JLabel nickLabel, passLabel;
	private JTextField nickField, passField;
	private JButton gestorebutton;
	private JButton registratiButton;

	public Login(Gestore gestore){
		this.gestore=gestore;
		setTitle("Gestione Parchi");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-130, f.height/2-100, 260, 200);
		createField();
		createButton();
		createPanel();
		this.setVisible(true);
	}
	public void createField()
	{ 
		nickLabel = new JLabel("NickName ");
		passLabel = new JLabel("Password ");
			
		nickField = new JTextField(10); //10 = lunghezza del rettangolo in cui inserire i dati
		passField = new JPasswordField(10); //10 = lunghezza del rettangolo in cui inserire i dati
			
		nickField.setText("");
		passField.setText("");
	}
	public void createButton(){
		gestorebutton=new JButton("Login");
		class AddGestoreButtonListener implements ActionListener
		{
			public void actionPerformed(ActionEvent event) 
			{
			
				String nickName = nickField.getText();
				String passName = passField.getText();
				if(passName.isEmpty()||nickName.isEmpty()){
					JOptionPane.showMessageDialog(null, "Campi vuoti, inserisci un nome utente e una Password");
				}
				else{
					if (nickName.equals("Admin") && passName.equals("admin"))
					{
						dispose();
						FrameGestore g=new FrameGestore(gestore);
					}
			        else {
			        	ArrayList<Agenzia> Agenzie=new ArrayList<Agenzia>();
					    Agenzie=gestore.getListaAgenzie();
					    boolean trovato=false;
						
					    for (Agenzia a:Agenzie) {
							if(a.getUser().equals(nickName)){
								if(a.getPassword().equals(passName)){
									trovato=true;
									FrameAgenzia f=new FrameAgenzia(a,gestore);
									dispose();
								}
		
								else{
									JOptionPane pane=new JOptionPane();
									pane.showMessageDialog(null, "Attenzione, Password Utente Errata!");
									pane.setVisible(true);
								}
					 		}
			            }
				        if(trovato==false){    
				        	JOptionPane pane=new JOptionPane();
							pane.showMessageDialog(null, "Impossibile trovare Utente: Nome o Password Errati");
							pane.setVisible(true);
			            }
			        }
				}
			}
		}
		
		ActionListener listener1 = new AddGestoreButtonListener();
		gestorebutton.addActionListener(listener1);
		
		registratiButton=new JButton("Registra Agenzia");
		class registra implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				String nickName=nickField.getText();
				String passName=passField.getText();
				if(passName.isEmpty()||nickName.isEmpty()){
					JOptionPane.showMessageDialog(null, "Campi vuoti, inserisci un nome utente e una Password");
				}
				else if(nickName.equals("Admin") && passName.equals("admin")){
					JOptionPane.showMessageDialog(null, "Nome utente già utilizzato");
				}
				else{
					ArrayList<Agenzia> agenzie=new ArrayList<Agenzia>();
					agenzie=gestore.getListaAgenzie();
					boolean trovato=false;
					for(Agenzia a:agenzie){
						if(a.getUser().equals(nickName)){
							trovato=true;
							JOptionPane pane=new JOptionPane();
							pane.showMessageDialog(null, "Nome utente già utilizzato, riprova");
							pane.setVisible(true);
						}
					}
					if(trovato==false){
						int yn=JOptionPane.showConfirmDialog(null,"Registrare una nuova agenzia con le credenziali precedenti?","Registrazione",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
						if(yn==JOptionPane.YES_OPTION){
							gestore.addAgenzia(nickName, passName);
						}
					}
				}
			}
				
			
		}
		ActionListener listener2=new registra();
		registratiButton.addActionListener(listener2);
	}
	public void createPanel()
	{

		JPanel panel = new JPanel();
		
		panel.setBackground(Color.LIGHT_GRAY);
		panel.add(nickLabel);
		panel.add(nickField);
		panel.add(passLabel);
		panel.add(passField);
		panel.add(gestorebutton);
		panel.add(registratiButton);
		add(panel, BorderLayout.CENTER);
	}
}

package ProgettoPROG2.FramePricipali;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ProgettoPROG2.Parchi.Gestore;
import ProgettoPROG2.Parchi.ParcoDivertimento;

public class FrameAddAttività extends JFrame{
	private JComboBox ParchiBox;
	private ArrayList<ParcoDivertimento> parchi;
	private Gestore gestore;
	private ActionListener listener;
	private JButton aggiungi;
	private JLabel nomelabel;
	private JTextField nomeField;
	private JLabel descrizioneLabel;
	private JTextField descrizioneField;
	private JButton bottoneIndietro;
	public FrameAddAttività(Gestore gestore){
		this.gestore=gestore;
		setTitle("Aggiungi Attività per un Parco");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f=Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/200-2, f.height/200-2, 300, 300);
		creaComboBox();
		creaPanel();
		setVisible(true);
		
	}
	public void creaComboBox(){
		ParchiBox=new JComboBox();
		parchi=gestore.getLista();
		for(ParcoDivertimento p:parchi){
			ParchiBox.addItem(p.getNome());
		}
		ParchiBox.setEditable(true);
		ParchiBox.addActionListener(listener);
	}
	public JPanel creaCampi(){
		nomelabel=new JLabel("Nome");
		nomeField=new JTextField();
		descrizioneLabel=new JLabel("Descrizione");
		descrizioneField=new JTextField();
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(2, 1));
		panel.add(nomelabel);
		panel.add(nomeField);
		panel.add(descrizioneLabel);
		panel.add(descrizioneField);
		return panel ;
		
	}
	public void creaPanel(){
		JPanel pannelloScelta=new JPanel();
		pannelloScelta.add(ParchiBox,BorderLayout.NORTH);
		pannelloScelta.add(creaCampi(), BorderLayout.CENTER);
		pannelloScelta.add(creaBottoni(), BorderLayout.SOUTH);
		add(pannelloScelta);
	}
    public JPanel creaBottoni(){
    	aggiungi=new JButton("Aggiungi");
    	
    	class Aggiungi implements ActionListener
    	{
    		public void actionPerformed(ActionEvent e) {
			    String nome=nomeField.getText();
			    String descrizione=descrizioneField.getText();
			    gestore.addAttività(nome, descrizione, parchi.get(ParchiBox.getSelectedIndex()));
			    JOptionPane.showMessageDialog(null,"La lista delle attività del parco è stata aggiornata correttamente"+parchi.get(ParchiBox.getSelectedIndex()).getlistaAttività());
		   }
        }
    	ActionListener list=new Aggiungi();
    	aggiungi.addActionListener(list);
        bottoneIndietro = new JButton("INDIETRO");
 		
 		class AddBottoneIndietroListener implements ActionListener
 		{
 			
 			public void actionPerformed(ActionEvent event) 
 			{
 				FrameGestore f = new FrameGestore(gestore);
 				dispose();
 			}
 		}
 			
 		ActionListener listener = new AddBottoneIndietroListener();
 		bottoneIndietro.addActionListener(listener);

    	JPanel panel=new JPanel();
    	panel.add(aggiungi);
    	panel.add(bottoneIndietro);
    	return panel;
    }
}

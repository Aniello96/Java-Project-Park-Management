package ProgettoPROG2.FramePricipali;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ProgettoPROG2.Parchi.BigliettiTerminatiException;
import ProgettoPROG2.Parchi.Cliente;
import ProgettoPROG2.Parchi.Gestore;
import ProgettoPROG2.Parchi.ParcoDivertimento;


public class FrameVendiBiglietto extends JFrame{
	/**
	 * Costruttore Frame Gestore
	 * @param gestore
	 */
	public FrameVendiBiglietto(Gestore gestore){
		this.gestore=gestore;
		setTitle("Vendi Biglietto");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-300, f.height/2-86, 600, 271);
		class ChoiseListener implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				scegliParco();
			}
		}
		listener=new ChoiseListener();
		creaBottone();
		createComboBox();
		createLabel();
		createField();
		CreatePanel();
		setVisible(true);
		
	}
	public void createLabel(){
		NomeClienteLabel=new JLabel("Nome: ");
		CognomeClienteLabel=new JLabel("Cognome: ");
		EtàLabel=new JLabel("Età: ");
		CodiceFiscaleLabel=new JLabel("Codice Fiscale: ");
		ParcoSceltoLabel=new JLabel("Scegli Parco:");
		
	}
	public void createField(){
		NomeField=new JTextField();
		CognomeField=new JTextField();
		CodiceFiscale=new JTextField();
		EtàField=new JTextField();
	}
	public void createComboBox(){
		ParchiBox=new JComboBox();
        parchi=gestore.getLista();
		for(ParcoDivertimento p:parchi){
			ParchiBox.addItem(p.getNome());
		}
		ParchiBox.setEditable(true);
		ParchiBox.addActionListener(listener);
	}
	public void CreatePanel(){
		JPanel pannelloLabel=new JPanel();
		pannelloLabel.setLayout(new GridLayout(4, 1));
		pannelloLabel.add(NomeClienteLabel);
		pannelloLabel.add(NomeField);
		pannelloLabel.add(CognomeClienteLabel);
		pannelloLabel.add(CognomeField);
		pannelloLabel.add(EtàLabel);
		pannelloLabel.add(EtàField);
		pannelloLabel.add(CodiceFiscaleLabel);
		pannelloLabel.add(CodiceFiscale);
		
		JPanel pannelloSceltaParco=new JPanel();
		pannelloSceltaParco.add(ParcoSceltoLabel);
		pannelloSceltaParco.add(ParchiBox);
		JPanel bottoni=new JPanel();
		bottoni.add(bottoneIndietro);
		bottoni.add(bottoneVendi);
		JPanel panel=new JPanel();
		panel.setLayout(new GridLayout(3, 1));

		panel.add(pannelloLabel);
		panel.add(pannelloSceltaParco);
		panel.add(bottoni);
		add(panel);
	}
	private void scegliParco() {
		Parcotemp=parchi.get(ParchiBox.getSelectedIndex());
	}
	public void creaBottone(){
		bottoneVendi=new JButton("Vendi Biglietto");
		class VendiListener implements ActionListener{

			private GregorianCalendar data;

			public void actionPerformed(ActionEvent e) {
				try{
					String nome=NomeField.getText();
					String cognome=CognomeField.getText();
					String CF=CodiceFiscale.getText();
					String dataNascita=EtàField.getText();
					int età=Integer.parseInt(dataNascita);
					if(nome.isEmpty()||cognome.isEmpty()||CF.isEmpty()||dataNascita.isEmpty()){
						JOptionPane.showMessageDialog(null,"Campi vuoti!");
					}
					else if((nome.length()>15||nome.length()<=1)||(cognome.length()>15||cognome.length()<=1)||CF.length()!=16||età<=0||età>=100){
						JOptionPane.showMessageDialog(null, "Campi non validi: inserisci Nome, Cognome, Età e Codice Fiscale validi");
					}
				    else{
				    	try{
					    	Cliente C=new Cliente(nome, cognome, CF,età);
							data=new GregorianCalendar();
							
							String bigliettoVenduto=gestore.VendiBiglietto(Parcotemp, data, C);
							JOptionPane.showMessageDialog(null, "Biglietto venduto correttamente.\n"+"Nome Cliente:"+nome+"\nBiglietto:"+bigliettoVenduto);
						}
					    catch(BigliettiTerminatiException b){
					    	JOptionPane.showMessageDialog(null, b.getMessage());
					    }
			        }
				}
			    catch(NumberFormatException n){
				     JOptionPane.showMessageDialog(null, n.getMessage());
			    }
			}
		}
		ActionListener listener2=new VendiListener();
		bottoneVendi.addActionListener(listener2);
		
		bottoneIndietro=new JButton("Indietro");
		class IndietroListener implements ActionListener{

			public void actionPerformed(ActionEvent e) {
				FrameGestore fg=new FrameGestore(gestore);
				dispose();
			}
			
		}
		ActionListener listener3=new IndietroListener();
		bottoneIndietro.addActionListener(listener3);
	}
	private Gestore gestore;
	private JComboBox ParchiBox;
	private ArrayList<ParcoDivertimento> parchi;
	private ParcoDivertimento Parcotemp;
	private JLabel NomeClienteLabel, CognomeClienteLabel, EtàLabel,CodiceFiscaleLabel,ParcoSceltoLabel;
	private JTextField NomeField,CognomeField, EtàField,CodiceFiscale;
	private JButton bottoneVendi, bottoneIndietro;
	private ActionListener listener;	
}




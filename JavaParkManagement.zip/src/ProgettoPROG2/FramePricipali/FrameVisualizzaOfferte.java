package ProgettoPROG2.FramePricipali;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import ProgettoPROG2.Parchi.Gestore;
import ProgettoPROG2.Parchi.Offerta;

public class FrameVisualizzaOfferte extends JFrame {
	private Gestore gestore;
	private JLabel label, inizioSettLabel, fineSettLabel, ggLabel, mmLabel, aaLabel, ggLabelF, mmLabelF, aaLabelF, partiteStadioLabel;
	private JTextField ggField, mmField, aaField, ggFieldF, mmFieldF, aaFieldF;
	private DefaultListModel listModel;
	private JButton bottoneVisualizza;
	private JPanel topPanel;
	private JList listbox;
	private JScrollPane scroll;
	private JButton bottoneIndietro;
	public FrameVisualizzaOfferte(Gestore g){
		this.gestore=g;
		setTitle("Visualizza Offerte");
		listModel = new DefaultListModel();
		
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-250, f.height/2-300, 500, 600);
		
		createField();
		creaBottone();
		createJList();
		createPanel();
		
		
		setVisible(true);
	}
	public void createField(){

		label = new JLabel("Selezionare il metodo di ordinamento delle partite: ");
		inizioSettLabel = new JLabel("Inizio Intervallo:  ");
		fineSettLabel = new JLabel("Fine Intervallo:   ");
		partiteStadioLabel = new JLabel("Visualizza le partite tenute in uno stadio   ");
		
		ggLabel = new JLabel("giorno");
		ggField = new JTextField(2);
		mmLabel = new JLabel(" mese");
		mmField = new JTextField(2);
		aaLabel = new JLabel("anno");
		aaField = new JTextField(4);
		
		ggLabelF = new JLabel("giorno");
		ggFieldF = new JTextField(2);
		mmLabelF = new JLabel(" mese");
		mmFieldF = new JTextField(2);
		aaLabelF = new JLabel("anno");
		aaFieldF = new JTextField(4);
	}
	public void creaBottone(){
		bottoneVisualizza=new JButton("Visualizza Offerte Attive");
		class ActionVisualizzaListener implements ActionListener{

			private GregorianCalendar dataInizio;
			private GregorianCalendar dataFine;

			public void actionPerformed(ActionEvent event) {
				try{
				int ggI = Integer.parseInt(ggField.getText());
				int mmI = Integer.parseInt(mmField.getText())-1;
				int aaI = Integer.parseInt(aaField.getText());
				int ggF = Integer.parseInt(ggFieldF.getText());
				int mmF = Integer.parseInt(mmFieldF.getText())-1;
				int aaF = Integer.parseInt(aaFieldF.getText());
				if(ggF<1||ggF>31 && mmF<1||mmF>12 && aaF<2000||aaF>2100){
					JOptionPane.showMessageDialog(null, "Inserisci una data di fine valida");
				}
				else if(ggI<1||ggI>31 && mmI<1||mmI>12 && aaI<2000||aaI>2100){
					JOptionPane.showMessageDialog(null, "Inserisci una data di inizio valida");
				}
				else{
				dataInizio = new GregorianCalendar(aaI,mmI,ggI);
				dataFine = new GregorianCalendar(aaF,mmF,ggF);
				listModel.clear();
				ArrayList<Offerta> listaOfferte=gestore.getListaOfferte();
				for(Offerta o:listaOfferte){
					if(o.getDataInizio().before(dataInizio)&&o.getDataFine().after(dataFine)){
						listModel.addElement(o.toString());
					}
				}
				}
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null,"Errore nella digitazione");
				}
			}
			
		}
		ActionListener ListenerVisualizza=new ActionVisualizzaListener();
		bottoneVisualizza.addActionListener(ListenerVisualizza);
		
        bottoneIndietro = new JButton("INDIETRO");
		
		class AddBottoneIndietroListener implements ActionListener
		{
			
			public void actionPerformed(ActionEvent event) 
			{
				FrameGestore f = new FrameGestore(gestore);
				dispose();
			}
		}
			
		ActionListener listener = new AddBottoneIndietroListener();
		bottoneIndietro.addActionListener(listener);
	}
	public void createJList()
	{

		// Create a panel to hold all other components
		topPanel = new JPanel();
		topPanel.setLayout(new BorderLayout());
		getContentPane().add( topPanel );

		// Create some items to add to the list
				
		listModel.addElement(" ");
		// Create a new listbox control
		listbox = new JList( listModel);
		topPanel.add( listbox, BorderLayout.CENTER);
		scroll = new JScrollPane(listbox);
		listbox.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		topPanel.add(scroll);
		
	}
	public void createPanel()
	{
		JPanel pannello = new JPanel();
		pannello.setLayout(new GridLayout(3, 1));
		
		JPanel pannelloInizio = new JPanel(); 
		pannelloInizio.add(inizioSettLabel);
		pannelloInizio.add(ggLabel);
		pannelloInizio.add(ggField);
		pannelloInizio.add(mmLabel);	
		pannelloInizio.add(mmField);
		pannelloInizio.add(aaLabel);
		pannelloInizio.add(aaField);
		pannelloInizio.setBackground(Color.ORANGE);
		
		pannello.add(pannelloInizio);
		
		JPanel pannelloFine = new JPanel();
		
		pannelloFine.add(fineSettLabel);
		pannelloFine.add(ggLabelF);
		pannelloFine.add(ggFieldF);
		pannelloFine.add(mmLabelF);	
		pannelloFine.add(mmFieldF);
		pannelloFine.add(aaLabelF);
		pannelloFine.add(aaFieldF);
		pannelloFine.add(bottoneVisualizza);

		pannelloFine.setBackground(Color.ORANGE);
		pannello.add(pannelloFine);
		pannello.add(topPanel);
        JPanel pannelloBottone = new JPanel();
		
		pannelloBottone.add(bottoneIndietro);
		
		pannelloBottone.setBackground(Color.ORANGE);
		
		add(pannelloBottone, BorderLayout.SOUTH);
		
		add(pannello, BorderLayout.CENTER);
		

	}
}

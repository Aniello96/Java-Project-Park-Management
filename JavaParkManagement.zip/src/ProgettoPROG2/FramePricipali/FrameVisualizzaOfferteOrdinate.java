package ProgettoPROG2.FramePricipali;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import ProgettoPROG2.Parchi.Attività;
import ProgettoPROG2.Parchi.Gestore;
import ProgettoPROG2.Parchi.Offerta;

public class FrameVisualizzaOfferteOrdinate extends JFrame {
	private Gestore gestore;
	private DefaultListModel listModel;
	private JLabel label;
	private JPanel pannello;
	private ActionListener listener;
	private JRadioButton lessicograficoRadioB;
	private JRadioButton cronologicoRadioB;
	private JButton bottoneIndietro;
	private JList listbox;
	private JPanel topPanel;
	private JScrollPane scroll;

	public FrameVisualizzaOfferteOrdinate(Gestore gestore){
		this.gestore=gestore;
		listModel = new DefaultListModel();
		
		
		setTitle("Visualizzazione Offerte");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-225, f.height/2-200, 550, 400);
		Image img = new ImageIcon("icon.png").getImage();
		this.setIconImage(img);
		
		
		label = new JLabel("Selezionare il metodo di ordinamento delle offerte: ");
		
		pannello = new JPanel();
		pannello.add(label, BorderLayout.NORTH);
		add(pannello, BorderLayout.NORTH);
		
		class sceltaOrdinamento implements ActionListener{

			public void actionPerformed(ActionEvent event) {
				setScelta();
				
			}
			
		}
		listener = new sceltaOrdinamento();
		createControlPanel();
		createButton();
		createJList();
		createPanel();
		
		setVisible(true);
	}
	public void createControlPanel()
	{
		JPanel buttonRadioPanel = createPulsantiRadio();
		
		JPanel controlPanel = new JPanel();
		controlPanel.add(buttonRadioPanel);
		
		this.add(controlPanel, BorderLayout.NORTH);
	}
	
	public JPanel createPulsantiRadio()
	{
		lessicograficoRadioB = new JRadioButton("Ordine LessicoGrafico");
		lessicograficoRadioB.addActionListener(listener);
		
		cronologicoRadioB = new JRadioButton("Ordine Cronologico");
		cronologicoRadioB.addActionListener(listener);
		
		
		//Il ButtonGroup è necessario per far si che solo uno dei bottoni possa essere selezionao
		
		ButtonGroup gruppoBR = new ButtonGroup();
		gruppoBR.add(lessicograficoRadioB);
		gruppoBR.add(cronologicoRadioB);
		
		JPanel panel = new JPanel();
		panel.add(lessicograficoRadioB);
		panel.add(cronologicoRadioB);
		
		//viene racchiuso il pannello tra bordi in rilievo
		panel.setBorder(new TitledBorder(new EtchedBorder(), "Odinamento:"));
		
		
		return panel;
		
	}
	public void createButton()
	{
		bottoneIndietro = new JButton("INDIETRO");
		
		class AddBottoneIndietroListener implements ActionListener
		{
			
			public void actionPerformed(ActionEvent event) 
			{
				JFrame FrameGestore = new FrameGestore(gestore);
				dispose();
			}
		}
			
		ActionListener listener = new AddBottoneIndietroListener();
		bottoneIndietro.addActionListener(listener);
	}
	public void createPanel()
	{
		JPanel pannello = new JPanel();
		
		pannello.add(bottoneIndietro);
		
		
		add(pannello, BorderLayout.SOUTH);
		
		
		add(topPanel, BorderLayout.CENTER);	
	}
	
	public void createJList()
	{
				topPanel = new JPanel();
				topPanel.setLayout( new BorderLayout() );
				getContentPane().add( topPanel );

				// Crea elementi da aggiungere alla lista
				
				listModel.addElement(" ");
				listbox = new JList( listModel );
				topPanel.add( listbox, BorderLayout.CENTER );
				scroll = new JScrollPane(listbox);
				listbox.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
				topPanel.add(scroll);
		
	}
	
	public void setScelta(){
		class ordinamentoLessicografico implements  Comparator <Attività>
		{

			public int compare(Attività a, Attività b) {
				
				return a.compareTo(b);
			}
			
		}
		
		class ordinamentoCronologico implements  Comparator <Offerta>
		{

			public int compare(Offerta event, Offerta event1) {
				
				return event.getDataFine().compareTo(event1.getDataFine());
			}

			
			
		}
		
		if (lessicograficoRadioB.isSelected())
		{
			listModel.clear();
			
			ArrayList<Attività> listaAttività = gestore.getListaAttivitàconOfferta();
			ArrayList<Offerta> listaOfferte = gestore.getOfferteAttive();
			
			Collections.sort(listaAttività, new ordinamentoLessicografico());
			
			for (Attività a: listaAttività)
			{
				listModel.addElement(a.toString());
				for(Offerta o: listaOfferte)
				{
					if(o.getCodice().equals(a.getCodice()))
					listModel.addElement(o.toString());
					
					
				}
			}
			
			
		}
		else if (cronologicoRadioB.isSelected())
		{
			listModel.clear();
			
			ArrayList<Offerta> listaOfferta = gestore.getOfferteAttive();
			
			Collections.sort(listaOfferta, new ordinamentoCronologico());
			
			for (Offerta o: listaOfferta)
			{
				listModel.addElement(o.toString());
			}
		}
		
	}
	}



package ProgettoPROG2.FramePricipali;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.print.DocFlavor.STRING;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javax.swing.ListSelectionModel;

import ProgettoPROG2.Agenzia.Agenzia;
import ProgettoPROG2.Agenzia.FrameAgenzia;
import ProgettoPROG2.Agenzia.Pacchetto;
import ProgettoPROG2.Parchi.Gestore;

public class FrameVisualizzaPacchetti extends JFrame{
	private Gestore Gestore;
	private JComboBox ag;
	private ArrayList<Agenzia> Agenzie;
	private JPanel topPanel;
	private DefaultListModel listModel;
	private JList listbox;
	private JScrollPane scroll;
	private ActionListener listener;
	public FrameVisualizzaPacchetti(Gestore g){
		//try{
		this.Gestore=g;
		setTitle("Visualizza Pacchetti in Vendita");
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-300, f.height/2-86, 600, 271);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		creaJlist();
		class scegliAgenzia implements ActionListener{
			public void actionPerformed(ActionEvent arg0) {
				Agenzia a=Agenzie.get(ag.getSelectedIndex());
				listModel.clear();
				for(Pacchetto p:a.getListapacchetti()){
					String Pacchetto=p.toString();
					if(p.prenotato()){
					Pacchetto+=(" PRENOTATO");
					}
					listModel.addElement(Pacchetto);
				}
				
			}
			
		}
		
		listener=new scegliAgenzia();
		creaPanel();
		setVisible(true);
		//}
		//catch (RuntimeException e) {
			//dispose();
			//Login l=new Login(Gestore);
		//}**/
	}
	public JComboBox selAgenzia(){
		ag=new JComboBox();
		Agenzie=Gestore.getListaAgenzie();
		if(Agenzie.size()==0){
			JOptionPane.showMessageDialog(null, "Impossibile Accedere, la lista delle Agenzie è vuota, Provvedere a inserire una nuova Agenzia");
			throw new RuntimeException();
		}
		for(Agenzia a:Agenzie){
			ag.addItem(a.getUser());
		}
		return ag;
	}
	public void creaJlist(){
		topPanel = new JPanel();
		topPanel.setLayout( new BorderLayout() );
		getContentPane().add( topPanel );
		listModel=new DefaultListModel();
		// Create some items to add to the list
		
		// Create a new listbox control
		listbox = new JList( listModel );
		topPanel.add( listbox, BorderLayout.CENTER );
		scroll = new JScrollPane(listbox);
		topPanel.add(scroll);
		
	}
	public void creaPanel(){
		JPanel panel=new JPanel();
		panel.add(selAgenzia(),BorderLayout.CENTER);
		
		JButton scegli=new JButton("Scegli Agenzia");
		scegli.addActionListener(listener);
		
		panel.add(scegli,BorderLayout.WEST);
		
		add(panel,BorderLayout.NORTH);
		
		add(topPanel,BorderLayout.CENTER);
        JButton bottoneIndietro = new JButton("INDIETRO");
		class AddBottoneIndietroListener implements ActionListener
		{
	 	public void actionPerformed(ActionEvent event) 
			{
				FrameGestore f= new FrameGestore(Gestore);
				dispose();
			}
		}
		
		ActionListener listener = new AddBottoneIndietroListener();
		bottoneIndietro.addActionListener(listener);
		add(bottoneIndietro,BorderLayout.SOUTH);
		
	}
}

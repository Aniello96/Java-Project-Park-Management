package ProgettoPROG2.FramePricipali;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import ProgettoPROG2.Parchi.Gestore;

public class FrameGestore extends JFrame{
	private Gestore g;
	public FrameGestore(Gestore g){
		this.g=g;
		disegnaGestore();
	}
	public void disegnaGestore()
		{
			Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
			setBounds(f.width/2-338, f.height/2-150, 675, 300);
			
			setTitle("Gestore");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
			
			JButton bottone1 = new JButton("Visualizza informazioni sui parchi divertimento gestiti");
			class AddBottone1Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event) 
				{
					FrameVisualizzaInfoParchi info=new FrameVisualizzaInfoParchi(g);
					dispose();
				}
					
			}
			
			ActionListener listener1 = new AddBottone1Listener();
			bottone1.addActionListener(listener1);
			
			
			JButton bottone2 = new JButton("visualizzare le promozioni attive in un determinato periodo di tempo");
			
			class AddBottone2Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event) 
				{
					FrameVisualizzaOfferte f=new FrameVisualizzaOfferte(g);
					dispose();
				}
			}
			
			ActionListener listener2 = new AddBottone2Listener();
			bottone2.addActionListener(listener2);
			
			
			JButton bottone3 = new JButton("visualizzare le promozioni attive per una determinata attività");
			
			class AddBottone3Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event) 
				{
					FrameVisualizzaOfferteOrdinate f=new FrameVisualizzaOfferteOrdinate(g);
					dispose();
				}
			}
			
			ActionListener listener3 = new AddBottone3Listener();
			bottone3.addActionListener(listener3);
			
			
			JButton bottone4 = new JButton("visualizzare i pacchetti in vendita da parte delle agenzie");
			
			class AddBottone4Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event) 
				{
					FrameVisualizzaPacchetti f=new FrameVisualizzaPacchetti(g);
					dispose();
				}
			}
			
			ActionListener listener4 = new AddBottone4Listener();
			bottone4.addActionListener(listener4);
			
			
			JButton bottone5 = new JButton("inserire nuove attività per un parco");
			
			class AddBottone5Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event) 
				{
					FrameAddAttività fa=new FrameAddAttività(g);
					dispose();
				}
			}
			
			ActionListener listener5 = new AddBottone5Listener();
			bottone5.addActionListener(listener5);
			
			
			JButton bottone8 = new JButton("vendere singoli biglietti");
			
			class AddBottone8Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event) 
				{
					FrameVendiBiglietto f=new FrameVendiBiglietto(g);
	            	dispose();
				}
			}
			
			ActionListener listener8 = new AddBottone8Listener();
			bottone8.addActionListener(listener8);
			
			
			JButton bottone7 = new JButton("Logout");
			
			class AddBottone7Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event) 
				{
					Login f=new Login(g);
					dispose();
				}
			}
			
			ActionListener listener7 = new AddBottone7Listener();
			 bottone7.addActionListener(listener7);
            
			JButton bottone9=new JButton("visualizzare l'incasso");
			class AddBottone9Listener implements ActionListener
			{
				public void actionPerformed(ActionEvent event)
				{
					FrameVisualizzaIncasso fi=new FrameVisualizzaIncasso(g);
					dispose();
				}
			}
			ActionListener listener9=new AddBottone9Listener();
			bottone9.addActionListener(listener9);
		
			JPanel pannello = new JPanel();
			
			
			pannello.add(bottone1);
			pannello.add(bottone2);
			pannello.add(bottone3);
			pannello.add(bottone4);
			pannello.add(bottone5);
			pannello.add(bottone8);
			pannello.add(bottone9);
			
			
			add(bottone7, BorderLayout.SOUTH);
			add(pannello, BorderLayout.CENTER);
		
			
			setVisible(true);
			
		}

	

}


package ProgettoPROG2.FramePricipali;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.xml.bind.Marshaller.Listener;

import ProgettoPROG2.Parchi.Gestore;
import ProgettoPROG2.Parchi.ParcoDivertimento;

public class FrameVisualizzaIncasso extends JFrame{
	private Gestore gestore;
    private ArrayList<ParcoDivertimento> parchi;
	private ActionListener listener2;
	private ParcoDivertimento parcoTemp;
	private JRadioButton ri,rs, rm;
	private JComboBox ParchiBox;
	private JButton bottoneIndietro;
	private JPanel centralPanel;
	private JTextArea Area;
	private ActionListener listener;
	
	public FrameVisualizzaIncasso(Gestore gestore){
		this.gestore=gestore;
		setTitle("Visualizza Incasso");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-225, f.height/2-200, 650, 300);
		parchi=gestore.getLista();
		class sceltaOrdinamento implements ActionListener{

			public void actionPerformed(ActionEvent event) {
				sceltaBottoni();
			}
			
		}
		class scegliParco implements ActionListener {
			
			public void actionPerformed(ActionEvent e){
				parcoTemp=parchi.get(ParchiBox.getSelectedIndex());
				System.out.println(parcoTemp.toString());
			}
		}
		listener2=new scegliParco();
		
		listener = new sceltaOrdinamento();
		CreaBox();
		createJArea();
		creaBottoni();
		createControlPanel();
		createButton();
		createPanel();
		setVisible(true);
	}
	public void CreaBox(){
	    ParchiBox=new JComboBox();
		for(ParcoDivertimento p:parchi){
			ParchiBox.addItem(p.getNome());
		}
		ParchiBox.addActionListener(listener2);
		ParchiBox.setEditable(true);
		
	}
	public void createControlPanel()
	{
		JPanel buttonRadioPanel = creaBottoni();
		
		JPanel controlPanel = new JPanel();
		controlPanel.add(ParchiBox);
		controlPanel.add(buttonRadioPanel);
		
		this.add(controlPanel, BorderLayout.NORTH);
	}
	
	public JPanel creaBottoni(){
	    ri=new JRadioButton("Incasso Giornaliero");
	    rs=new JRadioButton("Incasso Settimanale");
		rm=new JRadioButton("Incasso Mensile");
		ri.addActionListener(listener);
		rs.addActionListener(listener);
		rm.addActionListener(listener);
		ButtonGroup gruppoBR = new ButtonGroup();
		gruppoBR.add(ri);
		gruppoBR.add(rs);
		gruppoBR.add(rm);
		JPanel panel = new JPanel();
		panel.add(ri);
		panel.add(rs);
		panel.add(rm);
		
		//viene racchiuso il pannello tra bordi in rilievo
		panel.setBorder(new TitledBorder(new EtchedBorder(), "Incasso:"));
		
		
		return panel;
	}
	public void createButton()
	{
		bottoneIndietro = new JButton("INDIETRO");
		
		class AddBottoneIndietroListener implements ActionListener
		{
			
			public void actionPerformed(ActionEvent event) 
			{
				JFrame FrameGestore = new FrameGestore(gestore);
				dispose();
			}
		}
			
		ActionListener listener = new AddBottoneIndietroListener();
		bottoneIndietro.addActionListener(listener);
	}
	public void createPanel()
	{
		JPanel pannello = new JPanel();
		
		pannello.add(bottoneIndietro);
		
		
		add(pannello, BorderLayout.SOUTH);
		
		
		add(centralPanel, BorderLayout.CENTER);	
	}
	public void createJArea()
	{
		centralPanel = new JPanel();
		centralPanel.setLayout( new BorderLayout() );
		getContentPane().add( centralPanel );
        Area=new JTextArea();
        Area.setEditable(true);
	    centralPanel.add(Area);
		
	}
	
	public void sceltaBottoni(){
		if(ri.isSelected()){
			GregorianCalendar data=new GregorianCalendar();
			data.set(2016, 3, 2);
			double inc=parcoTemp.getIncassogiornaliero(data);
			Area.setText("L'incasso del giorno è:"+Double.toString(inc));

		}
		else if(rs.isSelected()){
			GregorianCalendar data=new GregorianCalendar();
			double inc=parcoTemp.getIncassoSettimanale(data);
			Area.setText("L'incasso della settimana è:"+Double.toString(inc));
		}
		else if(rm.isSelected()){
			GregorianCalendar data=new GregorianCalendar();
			double inc=parcoTemp.getIncassoMensile(data);
			Area.setText("L'incasso del mese è:"+Double.toString(inc));
		}
		       
	}
	
}

package ProgettoPROG2.FramePricipali;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.text.AbstractDocument.Content;

import ProgettoPROG2.Parchi.Biglietto;
import ProgettoPROG2.Parchi.Gestore;
import ProgettoPROG2.Parchi.ParcoAcquatico;
import ProgettoPROG2.Parchi.ParcoAvventura;
import ProgettoPROG2.Parchi.ParcoDivertimento;
import ProgettoPROG2.Parchi.ParcoTematico;

public class FrameVisualizzaInfoParchi extends JFrame {
	private Gestore gestore;
	private JComboBox parchiComboBox;
	private ArrayList<ParcoDivertimento> listaParchi;
	private ActionListener listener;
	private JLabel parcoLabel,ParcoNomeLabel, ParcoTelefonoLabel, ParcoSedeLabel, ParcoIncassoLabel;
	private JButton bottoneIndietro;
	private JLabel ParcoInfoLabel;
	private JPanel pannelloLabel;
	private JList listBox;
	private JScrollPane scroll;
	private DefaultListModel listModel;
	private JPanel topPanel;
	

	public FrameVisualizzaInfoParchi(Gestore g){
		this.gestore=g;
		setTitle("Visualizza info Parchi");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension f = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(f.width/2-148, f.height/2-104, 400, 300);
		class ChoiceListener implements ActionListener
		{
			public void actionPerformed(ActionEvent event) 
			{
				setText();
			}
			
		}
		
		listener = new ChoiceListener();
		createLabel();
		createComboBox();
		createButton();
		createPanel();
		
		setVisible(true);
	}
	public void createComboBox()
	{
		parchiComboBox = new JComboBox();
		
		listaParchi = gestore.getLista();
		
		for(ParcoDivertimento p : listaParchi)
		{
			parchiComboBox.addItem(p.getNome());
		}
		
		parchiComboBox.setEditable(true);
		
		parchiComboBox.addActionListener(listener);
	}
	public void createLabel()
	{
		parcoLabel = new JLabel("Seleziona un Parco dall'elenco");
		ParcoNomeLabel=new JLabel();
		ParcoSedeLabel=new JLabel();
		ParcoTelefonoLabel=new JLabel();
		ParcoInfoLabel=new JLabel();
		topPanel = new JPanel();
		topPanel.setLayout( new BorderLayout() );
		getContentPane().add( topPanel );
		listModel=new DefaultListModel();
		listBox=new JList(listModel);
		topPanel.add( listBox, BorderLayout.CENTER );
		scroll = new JScrollPane(listBox);
		topPanel.add(scroll);
	}
	public void setText()
	{
		
		
		ParcoDivertimento p = listaParchi.get(parchiComboBox.getSelectedIndex());
		ArrayList<Biglietto> listaBiglietti= p.getListaBiglietti();
		
		listModel.clear();
		for(Biglietto b:listaBiglietti){
		   listModel.addElement(b.toString());
		}
		ParcoNomeLabel.setText("Nome del Parco: "+p.getNome());
		ParcoSedeLabel.setText("Sede del Parco: "+p.getSede());
		ParcoTelefonoLabel.setText("Numero di Telefono: "+p.getTelefono());
	 
	    if(p instanceof ParcoAcquatico){
	    	ParcoInfoLabel.setText("Numero di piscine: "+((ParcoAcquatico) p).getNumPiscine());
	    }else
	    if(p instanceof ParcoTematico){
	    	ParcoInfoLabel.setText("Tema del Parco: "+((ParcoTematico)p).getTemaParco());
	    }else
	    if(p instanceof ParcoAvventura){
	    	ParcoInfoLabel.setText("Percorsi del Parco: "+((ParcoAvventura)p).stampapercorso());
	    }
	    
	}
	
	public void createButton()
	{
		bottoneIndietro = new JButton("INDIETRO");
		
		class AddBottoneIndietroListener implements ActionListener
		{
			
			public void actionPerformed(ActionEvent event) 
			{
				JFrame frameGestore = new FrameGestore(gestore);
				dispose();
			}
		}
		
		ActionListener listener = new AddBottoneIndietroListener();
		bottoneIndietro.addActionListener(listener);
		
	}
	public void createPanel()
	{
		JPanel pannelloBox = new JPanel();
		
		pannelloBox.add(parcoLabel);
		pannelloBox.add(parchiComboBox);

		pannelloLabel=new JPanel();
	  	pannelloLabel.setLayout(new GridLayout(4, 1));
	    pannelloLabel.add(ParcoNomeLabel);
	    pannelloLabel.add(ParcoSedeLabel);
	  	pannelloLabel.add(ParcoTelefonoLabel);
	  	pannelloLabel.add(ParcoInfoLabel);
	  	
		JPanel pannelloBottoni = new JPanel();
		
		pannelloBottoni.add(bottoneIndietro);
		
		
		add(pannelloBox, BorderLayout.NORTH);
		add(pannelloLabel, BorderLayout.WEST);
		add(topPanel, BorderLayout.CENTER);
		add(pannelloBottoni, BorderLayout.SOUTH);
	
	}

}

package ProgettoPROG2.Parchi;

public class ParcoAcquatico extends ParcoDivertimento{
	/**
	 * 
	 * @param nome
	 * @param sede
	 * @param numTelefono
	 * @param numBiglietti
	 * @param numPiscine
	 */
	public ParcoAcquatico(String nome,String sede, String numTelefono,int numBiglietti,int numPiscine){
		super(nome, sede, numTelefono,numBiglietti);
		this.numPiscine=numPiscine;
	}
	/**
	 * @return numero di piscine
	 */
	public int getNumPiscine(){
		return numPiscine;
	}
	/**
	 * informazioni parco
	 */
    public String toString(){
    	return "Nome Parco: "+super.nome+"\n Sede: "+super.sede+"\nNumero di Telefono: "+super.numTelefono+"\nNumero Piscine: "+numPiscine;
    }
    
	private int numPiscine;
}

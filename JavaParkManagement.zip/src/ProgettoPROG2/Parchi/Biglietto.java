package ProgettoPROG2.Parchi;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Biglietto {
	/**
	 * Costruttore Biglietto
	 * @param codiceid
	 * @param data
	 * @param prezzo
	 */
	public Biglietto(String codiceid,GregorianCalendar data, double prezzo){
		this.codiceId=codiceid;
        this.Data=data;
        this.prezzo=prezzo;
	}
	/**
	 * metodo toString
	 * @return informazioni del Biglietto
	 */
	public String toString(){
		return "Biglietto numero:"+codiceId+"\nData:"+Data.get(Calendar.DATE)+"/"+Data.get(Calendar.MONTH)+1+"/"+Data.get(Calendar.YEAR)+"\nPrezzo:"+prezzo;
	}
	/**
	 * @return la Data in cui è stato emesso il biglietto
	 */
	public GregorianCalendar getData(){
		return Data;
	}
	private String codiceId;
	private GregorianCalendar Data;
    private double prezzo;
}

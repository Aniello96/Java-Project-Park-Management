package ProgettoPROG2.Parchi;

public class EccezioneOfferta extends RuntimeException {
     public EccezioneOfferta(){
	      super("L'attività ha già un offerta");
     }
}

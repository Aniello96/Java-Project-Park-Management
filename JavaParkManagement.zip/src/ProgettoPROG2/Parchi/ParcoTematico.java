package ProgettoPROG2.Parchi;

public class ParcoTematico extends ParcoDivertimento {
	/**
	 * @param nome
	 * @param sede
	 * @param numero
	 * @param numeroBiglietti
	 * @param tema
	 */
	private  String tema_init;
	public ParcoTematico (String nome,String sede,String numTelefono,int numBiglietti,String tema_init){
		super(nome,sede,numTelefono,numBiglietti);
		this.tema_init = tema_init;
	}
	/**
	 * @return Restituisce il tema
	 */
	public String getTemaParco(){
		return this.tema_init;
	}
	/**
	 * informazioni parco
	 */
	public String toString(){
		return "Nome Parco: "+super.nome+"\n Sede: "+super.sede+"\nNumero di Telefono: "+super.numTelefono+"Il tema del parco è : "+tema_init+"\n";
		
	}
}	
	
package ProgettoPROG2.Parchi;

public class Attività {
	/**
	 * Un'Attività è caratterizzata da un nome e una descrizione.
	 * @param nome
	 * @param descrizione
	 */
	public Attività(String nome, String descrizione){
		this.nome=nome;
		this.descrizione=descrizione;
		this.inOfferta=false;
	}
	/**
	 * @return nome dell'attività
	 */
	public String nome(){
		return nome;
	}
	/**
	 * Setta l'offerta dell'attività.
	 * @param nuova Offerta
	 * @throws RuntimeException 
	 */
	public void setOfferta(Offerta o) throws RuntimeException{
		if(inOfferta==true){
		throw new EccezioneOfferta();
		}
		else {
			promo=o;
			inOfferta=true;
		}
	}
	/**
	 * @return inOfferta
	 */
	public boolean inOfferta(){
		return inOfferta;
	}
	/**
	 * Cancella l'offerta.
	 */
	public void delOfferta(){
		promo=null;
		inOfferta=false;
	}
	/**
	 * restituisce la percentuale dell'offerta.
	 * @return percentuale
	 */
	public int percentualeofferta(){
		return promo.getPercentuale();
		
	}
	/**
	 * Informazioni dell'attività
	 */
	public String toString(){
	
		if(inOfferta==true)
			return "\nNome Attività: "+nome+"\nDescrizione Attività: "+descrizione+"\nAttiva: Si"+"\nDescrizione Offerta: "+promo.toString();
		else 
			return "Nome Attività: "+nome+"\nDescrizione Attività: "+descrizione+"\nAttiva: No";
	}
	/**
	 * Metodo che confronta due attività.
	 */
	public int compareTo(Attività b) {
		if(this.nome.compareTo(b.nome)<0)
		    return -1;
		else if(this.nome.compareTo(b.nome)==0)
			return 0;
		else 
			return 1;
	}
	/**
	 * Restituisce il codice della promozione.
	 * @return codice
	 */
	public String getCodice(){
		return promo.getCodice();
	}
	private boolean inOfferta;
	private Offerta promo;
	private String nome;
	private String descrizione;
	
	
}

package ProgettoPROG2.Parchi;

public class ParcoAvventura extends ParcoDivertimento{
	private String [][] percorso;
	private int percorsidisponibili;

	/**
	 * @param nome
	 * @param sede
	 * @param numTelefono
	 * @param numBiglietti
	 */
	public ParcoAvventura(String nome,String sede,String numTelefono,int numBiglietti){
		super(nome, sede, numTelefono,numBiglietti);
	}
	/**
	 * Aggiunge un percorso al parco. Per ogni percorso disponibile, vi è associata la sua descrizione.
	 * @param nomePercorso
	 * @param Descrizione
	 */
	public void addPercorso(String nomePercorso, String Descrizione){
		percorsidisponibili++;
		percorso=new String[percorsidisponibili][2];
		for(int i=0;i<percorsidisponibili;i++){
			for(int j=0;j<2;j++)
				if(j==0)
				percorso[i][j]=nomePercorso;
				else
				percorso[i][j]=Descrizione;
		}	
		
	}
	/**
	 * Stampa il percorso del parco.
	 * @return Stampa
	 */
	public String stampapercorso(){
		String Stampa="";
		for(int i=0;i<percorsidisponibili;i++){
			Stampa+=(i+1)+" ";
			for(int j=0;j<2;j++){
		    if(j==0)
			     Stampa+="Nome "+percorso[i][j];
		    else
		    	 Stampa+=" Descrizione "+percorso[i][j];
			}
			Stampa+="\n";
		}
		return Stampa;
	}
	/**
	 * informazioni del parco
	 */
    public String toString(){
	    return "Nome Parco: "+super.nome+"\n Sede: "+super.sede+"\nNumero di Telefono: "+super.numTelefono+"\nNumero di percorsi disponibili:"+percorsidisponibili;
	}
}

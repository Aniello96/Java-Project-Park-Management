package ProgettoPROG2.Parchi;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import ProgettoPROG2.Agenzia.*;
public class Gestore {
	/**
	 * @param lista parchi
	 * @param lista agenzie
	 * @param lista offerte
	 * @param lista attivit�
	 */
	public Gestore(){
		Parchi=new ArrayList<ParcoDivertimento>();
		Agenzie=new ArrayList<Agenzia>();
		Offerte=new ArrayList<Offerta>();
		AttivitàParchi=new ArrayList<Attività>();
		Clienti=new ArrayList<Cliente>();
	}
	/**
	 * Metodo che vende il biglietto al cliente .Ci salviamo in una variabile il prezzo del biglietto. Dopodichè verifichiamo se il biglietto
	 * deve essere acquistato in un parco acquatico/tematico o avventura. Aggiungiamo il biglietto al cliente e aggiorniamo i biglietti venduti.
	 * Se l'operazione non va a buon fine vuol dire che i biglietti sono esauriti e quindi viene lanciata un'eccezione.
	 * @param Parco Scelto dal Cliente
	 * @param data in cui viene Acquistato il biglietto
	 * @param Cliente che acquista il biglietto
	 * @return Una Stringa che rappresenta il Biglietto appena venduto
	 */
	public String VendiBiglietto(ParcoDivertimento p,GregorianCalendar data,Cliente c){
		try{
			String codiceID="";
			double prezzo=p.setPrezzoBiglietto();
			if(p instanceof ParcoAcquatico){
			    numeroBigliettiProgressivi++;
			    codiceID="PAC"+numeroBigliettiProgressivi;
			}
			else if(p instanceof ParcoTematico){
				numeroBigliettiProgressivi++;
				codiceID="PAT"+numeroBigliettiProgressivi;
			}
			else if(p instanceof ParcoAvventura){
				numeroBigliettiProgressivi++;
				codiceID="PAV"+numeroBigliettiProgressivi;
			}
			Biglietto b=new Biglietto(codiceID,data,prezzo);
			p.aggiornabigliettivenduti(b);
			c.addBiglietto(b);
			return b.toString();
			
		}catch(BigliettiTerminatiException e){
			throw e;
		}
	}
	/**
	 * Metodo che aggiunge un parco al gestore
	 * @param p
	 */
	public void addParco(ParcoDivertimento p){
		Parchi.add(p);
	}
	/**
	 * Metodo che aggiunge un'Attività a un Parco
	 * @param nome atività
	 * @param descrizione attività
	 * @param Parco al quale aggiungere l'attività
	 */
	public void addAttività(String nome,String descrizione,ParcoDivertimento p){
		Attività a=new Attività(nome, descrizione);
		AttivitàParchi.add(a);
		p.add(a);
	}
	/**
	 * @return la lista delle attività con un offerta attiva
	 */
	public ArrayList<Attività> getListaAttivitàconOfferta(){
		ArrayList<Attività> att=new ArrayList<Attività>();
		for(Attività a:AttivitàParchi){
			if(a.inOfferta()==true){
				att.add(a);
			}
		}
		return att;
	}
	/**
	 * Metodo che aggiunge un offerta a un attività. Se l'attività ha già un'offerta attiva allora viene lanciata un'eccezione.
	 * @param offerta da aggiungere
	 * @param nome dell'Attività cui si vuole aggiungere l'offerta
	 */
	public void AddOfferta(Offerta off,String nomeAttività){
        for(ParcoDivertimento p:Parchi){
        	if(p.cercaAttività(nomeAttività)==true){
        		try{
        		p.addOfferta(off, nomeAttività);
                Offerte.add(off);
        		}
        		catch(EccezioneOfferta e){
        			System.out.println("Console:"+e.getMessage());
        		}
        	}
            else
            	new IllegalArgumentException();
        }  	
	}
	/**
	 * Metodo che aggiunge un nuovo Cliente alla Struttura mediante user e password
	 * @param nome = UserName
	 * @param password
	 */
	public void addAgenzia(String nome, String password)
	{
		boolean done = false;
		
		for(Agenzia a : Agenzie)
		{
			
			if(a.getUser().equals(nome))
			{
				done = true;
			}
		}
		
		if(done)
		{
			throw new RuntimeException("Console: Nickname già utilizzato");
		}
		else
		{
			Agenzie.add(new Agenzia(nome, password,this));
		}
		
		
	}
	/**
	 * 
	 * @return la lista delle agenzie
	 */
	public ArrayList<Agenzia> getListaAgenzie() {
		return Agenzie;
	}
    /**
     * @return visualizza la lista delle attività
     */
	public String visualizzaAttività(){
		String visualizza="";
		for (ParcoDivertimento p:Parchi){
			visualizza+=p.getlistaAttività();
		}
		return visualizza;
	}
	/**
	 * Metodo che visualizza le offerte attive in un determinato periodo di tempo.
	 * @param giorno
	 * @param mese
	 * @return listaOfferte
	 */
	public String visualizzaOfferteAttive(int giorno,int mese){
		String listaOfferte="";
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/2016");
		for(Offerta o:Offerte){
		}
		return listaOfferte;
	}
	/**
	 * Metodo che restituisce le offerte attive.
	 * @return off
	 */
	public ArrayList<Offerta> getOfferteAttive(){
		ArrayList<Offerta> off=new ArrayList<Offerta>();
		GregorianCalendar data=new GregorianCalendar();
		for(Offerta o:Offerte){
			if(o.getDataInizio().before(data)&&o.getDataFine().after(data)){
				off.add(o);
			}
		}
		return off;
	}
	/**
	 * Restituisce la lista delle offerte.
	 * @return Offerte
	 */
	public ArrayList<Offerta> getListaOfferte() {
		return Offerte;
	}
	/**
	 * Restituisce la lista di parchi.
	 * @return Parchi
	 */
	public ArrayList<ParcoDivertimento> getLista(){
		return Parchi;
	}
	/**
	 * Metodo che aggiorna il gestore in un file stampando tutte le informazioni relative.
	 */
	public void addCliente(Cliente c){
		Clienti.add(c);
	}
	public ArrayList<Cliente> getListaClienti(){
		return Clienti;
	}
	
	public boolean trovaCliente(Cliente C){
		boolean trovato=false;
		if(Clienti.size()==0){
			return false;
		}
		for(Cliente cl:Clienti){
			if(cl.getCodiceFiscale().equals(C.getCodiceFiscale())){
				trovato=true;
			}
		}
		return trovato;
	}
	public Cliente getCliente(String codiceFiscale){
		Cliente temp = null;
		for(Cliente c:Clienti){
			if(c.getCodiceFiscale().equals(codiceFiscale)){
			 temp = c;
			}
		}
		return temp;
	}
	private ArrayList<Cliente> Clienti ;
	private ArrayList<Attività> AttivitàParchi;
	private ArrayList<Offerta> Offerte;
	private ArrayList<Agenzia> Agenzie;
	private ArrayList<ParcoDivertimento> Parchi;
	private int numeroBigliettiProgressivi;

	
}

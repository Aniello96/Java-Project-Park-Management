package ProgettoPROG2.Parchi;
import java.util.ArrayList;

import ProgettoPROG2.Agenzia.*;
/**
 * 
 * @author Francesco
 *
 */
public class Cliente {
	/**
	 * Costruttore Cliente
	 * @param nome
	 * @param cognome
	 * @param CodiceFiscale
	 * @param età
	 */
	public Cliente(String nome,String cognome,String CodiceFiscale,int età){
		
		this.nome=nome;
		this.CF=CodiceFiscale;
		this.cognome=cognome;
		this.età=età;
		listabigliettiacquistati=new ArrayList<Biglietto>();
		pacchettoAcquistato=false;
		pacchettoPrenotato=false;
	}
	/**
	 * 
	 * @return codiceFiscale
	 */
	public String toString(){
		return nome+" "+cognome;
	}
	public String getCodiceFiscale(){
		return CF;
	}
	/**
	 * 
	 * @return nome
	 */
	public String getNome(){
		return nome;
	}
	/**
	 * 
	 * @return cognome
	 */
	public String getCognome() {
		return cognome;
	}
	/**
	 * 
	 * @return età
	 */
	public int getEtà(){
		return età;
	}
	/**
	 * Aggiunge un biglietto alla lista dei biglietti Acquistati
	 * @param Biglietto Acquistato
	 */
	public void addBiglietto(Biglietto b){
		listabigliettiacquistati.add(b);
	}
	/**
	 * 
	 * @return la lista dei biglietti Acquistati dal Cliente
	 */
	public ArrayList<Biglietto> getListaBiglietti(){
		return listabigliettiacquistati;
	}
	/**
	 * Metodo che setta il Pacchetto al Cliente
	 * @param Pacchetto Acquistato dal Cliente
	 * @return true se il pacchetto è stato acquistato correttamente
	 */
	public boolean controllaAcquisto(){
		return pacchettoAcquistato;
	}
	public void Acquista(Pacchetto p){
		Acquistato=p;
		pacchettoAcquistato=true;
	}
	public boolean controllaPrenotazione() {
		return pacchettoPrenotato;
	}
	/**
	 * Metodo che permette di prenotare un Pacchetto
	 * @param Pacchetto prenotato dal Clientee
	 */
	public void PrenotaPacchetto(Pacchetto p){
		Prenotato=p;
		pacchettoPrenotato=true;
	}
	/**
	 * 
	 * @return Pacchetto Acquistato dal Cliente
	 */
	public Pacchetto getPacchettoAcquistato(){
		return Acquistato;
	}
	/**
	 * 
	 * @return Pacchetto prenotato dal Cliente
	 */
	public Pacchetto getPacchettoPrenotato() {
		return Prenotato;
	}
	private boolean pacchettoAcquistato;
	private boolean pacchettoPrenotato;
	private Pacchetto Acquistato;
	private Pacchetto Prenotato;
	private ArrayList<Biglietto> listabigliettiacquistati;
	private String nome;
	private String cognome;
	private String CF;
	private int età;

}

package ProgettoPROG2.Parchi;

public class BigliettiTerminatiException extends RuntimeException {
	public BigliettiTerminatiException(){
		super("Impossibile completare operazione i biglietti sono finiti");
	}
}

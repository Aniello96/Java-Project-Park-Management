package ProgettoPROG2.Parchi;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*; //per GregorianCalendar



/* COSTRUTTORE : SimpleDateFormat serve per settare il formato che desideriamo utilizzare per rappresentare la data. Instanziamo 2 oggetti di tipo
 * GregorianCalendar per poterci salvare le date che abbiamo scelto attraverso il metodo .setTime(GregorianCalendar) e .parse(SimpleDateFormat).
 * Il metodo .parse della classe SimpleDateFormat riceve in ingresso una stringa e restituisce un oggetto Date. 
 * Il metodo .setTime della classe GregorianCalendar ci permette di impostare la data.
 * Questa operazione potrebbe sollevare una ParseException, nel caso in cui la stringa passata al metodo parse(), non rappresenti una data convertibile. */ 
public class Offerta {
	/**
	 * @param data inizio offerta
	 * @param data fine offerta
	 * @param codice
	 * @param nome
	 * @param percentuale
	 */
	public Offerta(String data1,String data2,String codice_init,String nome_init,int percentuale){
		this.codice = codice_init;
		this.nome = nome_init;
		this.percentuale= percentuale;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		datainizio = new GregorianCalendar();
		datafine = new GregorianCalendar();
		try{
			datainizio.setTime(sdf.parse(data1));
		}
		catch(ParseException e){
			e.printStackTrace();
			
		}
		try{
			datafine.setTime(sdf.parse(data2));
		}
		catch(ParseException e){
			e.printStackTrace();
				
		}	
		
	}
	/**
	 * @return codice
	 */
	public String getCodice(){
		return codice;
	}
	/**
	 * @return datainizio
	 */
	public GregorianCalendar getDataInizio(){
		return datainizio;
	}
	/**
	 * @return datafine
	 */
	public GregorianCalendar getDataFine(){
		return datafine;
	}
	/**
	 * @return percentuale
	 */
	public int getPercentuale(){
		return percentuale;
	}
	/**
	 * @return la data di inizio dell'offerta come stringa
	 */
	public String StringDataInizio(){
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		return sdf1.format(datainizio.getTime());
	}
	/**
	 * @return la data finale dell'offerta come stringa
	 */
	public String StringDataFine(){
		SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
		return sdf2.format(datafine.getTime());
	}
	/**
	 * restituisce le informazioni riguardanti l'offerta
	 */
	public String toString(){
		return " Nome:"+nome+", Codice: "+codice+", Data Inizio: "+StringDataInizio()+", Data Fine: "+StringDataFine()+", Percentuale: "+getPercentuale();
	}
	
private GregorianCalendar datainizio ;
private GregorianCalendar datafine ;
private String nome;
private String codice;
private int percentuale;



}


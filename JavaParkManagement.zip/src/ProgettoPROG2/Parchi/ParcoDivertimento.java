package ProgettoPROG2.Parchi;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;


public abstract class ParcoDivertimento {
	
   /**
    * Vogliamo tener conto anche dell'incasso giornaliero, settimanale,mensile e annuale.
    * @param nome
    * @param sede
    * @param numTelefono
    * @param numBigliettiGiornalieri
    */
	public ParcoDivertimento(String nome, String sede,String numTelefono,int numBigliettiGiornalieri){
    	this.nome=nome;
    	this.sede=sede;
    	this.numTelefono=numTelefono;
	    this.bigliettiInVendita=numBigliettiGiornalieri;
	    
	    listaAttività=new ArrayList<Attività>();
	    date=new ArrayList<GregorianCalendar>();
        bigliettiVenduti=new ArrayList<Biglietto>();
	    bigliettigiorno=new int[367];
        
	    for(int i=0;i<bigliettigiorno.length;i++){
        	bigliettigiorno[i]=bigliettiInVendita;
        }
        incassoAnno=new double[10];
        incassogiorno=new double [367];
        incassosett=new double [53];
        incassomese=new double[12];
    }
	/**
	 * @return il nome del parco
	 */
    public String getNome(){
    	return nome;
    }
    /**
     * @return la sede
     */
    public String getSede() {
		return sede;
	}
    /**
     * @return numero telefonico
     */
    public String getTelefono() {
		return numTelefono;
	}
    /**
     * @return lista di biglietti venduti
     */
    public ArrayList<Biglietto> getListaBiglietti() {
		return bigliettiVenduti;
	}
    /**
     * Per convenzione abbiamo settato il periodo tra il 2010 e il 2020 . Controlliamo se il biglietto esiste già, altrimenti aggiorniamo il biglietto
     * Infine aggiorniamo i vari incassi e il numero di biglietti disponibili.
     * @param Biglietto b
     */
	public void aggiornabigliettivenduti(Biglietto b) {
		GregorianCalendar data=b.getData();
		int anno=data.get(Calendar.YEAR);
		if(anno<2010&&anno>2020){
			new RuntimeException();
		}
		else{
			int giorno = data.get(Calendar.DAY_OF_YEAR);
			int sett= data.get(Calendar.WEEK_OF_YEAR);
			int mese=data.get(Calendar.MONTH);
			boolean trovato=false;
			for(GregorianCalendar d:date){
				if(data.equals(d)){
					trovato=true;
				}
			}
			if (trovato==false)date.add(data);
			for(GregorianCalendar d:date){
				if(data.equals(d)){
					if(bigliettigiorno[giorno]==0){
						 throw new BigliettiTerminatiException();
					}
					else{
						bigliettiVenduti.add(b);
					    bigliettigiorno[giorno]--;
					    incassogiorno[giorno]+=setPrezzoBiglietto();
					    incassosett[sett]+=setPrezzoBiglietto();
					    incassomese[mese]+=setPrezzoBiglietto();
					}
				}	
			}
		}
	}	
	
    /**
     * Controlliamo se c'è un'offerta sul biglietto. Se si,allora,il prezzo del biglietto sar� scontato in base alla sua percentuale sconto.
     * Infine si aggiorna il prezzo totale e lo si restituisce.
     * @return prezzoTotale
     */
	public double setPrezzoBiglietto(){
    	int prezzo=10;
        double prezzoTotale=10;
    	double prezzoperAttività;
    	for(Attività a:listaAttività){
    		if (a.inOfferta()==true){
    			double perc=((double)a.percentualeofferta())/100;
    			prezzoperAttività=prezzo*perc;
    		}else{
    			prezzoperAttività=prezzo;
    		}
    		prezzoTotale+=prezzoperAttività;
    	}
       
    	return prezzoTotale;
    }
	/**
	 * Aggiungiamo un'attivit� alla lista delle attivit�.
	 */
    public void add(Attività a){
    	
    	listaAttività.add(a);
    }
    /**
     * Restituisce la lista di attivit�.
     * @return lista
     */
    public String getlistaAttività(){
   
    	String lista="";
    	for(Attività a:listaAttività){
    		lista+=a.toString();
    	}
    	return lista;
    }
    /**
     * Controlla se esiste un'attivit� con lo stesso nome dato in input.
     * @param nome
     * @return trovato
     */
    public boolean cercaAttività(String nome){
    	boolean trovato=false;
    	for(Attività a:listaAttività)
    		if(a.nome()==nome)
    			trovato=true;
        return trovato;
    }
    /**
     * Controlla se esiste un'attivit� con lo stesso nome dato in input.Se si,allora,le associamo un'offerta.
     * Se possiede gi� un'offerta, allora viene lanciata un'eccezione.
     * @param o
     * @param nome
     */
    public void addOfferta(Offerta o,String nome){
    	for(Attività a:listaAttività)
    		if(a.nome()==nome)
    			try{
    			a.setOfferta(o);
    			}catch(EccezioneOfferta e){
    				throw e;
    			}
    }
    /**
     * Restituisce l'incasso giornaliero
     * @param data
     * @return incasso
     */
    public double getIncassogiornaliero(GregorianCalendar data){
    	double incasso=0;
    	for(int i=1;i<=367;i++)
    	if(data.get(Calendar.DAY_OF_YEAR)==i){
    		incasso=incassogiorno[i];
    	}
    	return incasso;
    }
    /**
     * Restituisce l'incasso mensile.
     * @param data
     * @return incasso
     */
    public double getIncassoMensile(GregorianCalendar data){
    	double incasso=0;
    	for(int i=0;i<=11;i++)
    	if(data.get(Calendar.MONTH)==i){
    		incasso=incassomese[i];
    	}
    	return incasso;
    }
    /**
     * Restituisce l'incasso settimanale.
     * @param data
     * @return incasso
     */
    public double getIncassoSettimanale(GregorianCalendar data){
    	double incasso=0;
    	for(int i=1;i<=52;i++)
    	if(data.get(Calendar.WEEK_OF_YEAR)==i){
    		incasso=incassosett[i];
    	}
    	return incasso;
    }
    
    private int bigliettiInVendita;
    private ArrayList<Biglietto> bigliettiVenduti;
    protected ArrayList<Attività> listaAttività;
    protected String nome;
    protected String sede;
    protected String numTelefono;
    private int[] bigliettigiorno;
   	private ArrayList<GregorianCalendar> date;
   	private double[] incassogiorno;
   	private double[] incassosett;
   	private double[] incassomese;
   	private double[] incassoAnno;
    }

import java.util.ArrayList;
import java.util.GregorianCalendar;

import ProgettoPROG2.FramePricipali.Login;
import ProgettoPROG2.Parchi.Cliente;
import ProgettoPROG2.Parchi.Gestore;
import ProgettoPROG2.Parchi.Offerta;
import ProgettoPROG2.Parchi.ParcoAcquatico;
import ProgettoPROG2.Parchi.ParcoAvventura;
import ProgettoPROG2.Parchi.ParcoDivertimento;
import ProgettoPROG2.Parchi.ParcoTematico;

public class main {
public static void main(String[] args) {
	ParcoAvventura a=new ParcoAvventura("Avventura", "Milano", "081 562876",10);
	a.addPercorso("Giallo", "Un insieme di avventure nel mondo dei sogni");
	ParcoTematico t=new ParcoTematico("Tematico", "Napoli", "087 31467", 100, "Corsa");
	ParcoAcquatico acq=new ParcoAcquatico("Acquatico", "Avellino", "0825 875876", 200, 10);
	Gestore g=new Gestore();
	g.addParco(a);
	g.addParco(t);
	g.addParco(acq);
	
	GregorianCalendar data=new GregorianCalendar();
	GregorianCalendar data2=new GregorianCalendar();
	GregorianCalendar data3=new GregorianCalendar();
	GregorianCalendar data4=new GregorianCalendar();
	
	data.set(2016, 3, 28);
	data2.set(2016, 3, 10);
	data3.set(2016,3,7);
	data4.set(2016,2,8);
	GregorianCalendar data5=new GregorianCalendar();
	g.VendiBiglietto(a, data5, new Cliente("nome", "cognome", "CodiceFiscale",18));
	g.VendiBiglietto(a,data2 ,new Cliente("nome2", "cognome", "CodiceFiscale",22));
	g.addAttività("Corsa", "Una corsa di 10 Kilometri", t);
	g.addAttività("Nuoto", "Un Occasione per nuotare con gli amici", acq);
	g.addAttività("Paura","Un Attività per veri amanti dell'Adrenalina", a);
	Offerta off=new Offerta("28/11/1994", "28/12/2020" , "OFF001","Sconto del 70%", 70);
	Offerta off2=new Offerta("28/1/2000", "28/12/2017" , "OFF002","Sconto del 30%", 30);
	Offerta off3=new Offerta("28/12/1994", "28/12/2018" , "OFF003","Sconto del 20%", 20);
	g.AddOfferta(off,"Corsa");
	g.AddOfferta(off3, "Corsa");
	g.AddOfferta(off2,"Nuoto");
	g.AddOfferta(off3, "Paura");
	Login s=new Login(g);
	g.VendiBiglietto(a,data2 ,new Cliente("nome2", "cognome", "CodiceFiscale",30));
}
}
